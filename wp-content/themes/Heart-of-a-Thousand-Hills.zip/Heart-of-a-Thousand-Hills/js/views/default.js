/*globals window, document, define, $, Backbone, console, Modernizr, Fonts, alert*/

define([], function () {
    'use strict';
    console.log('Home Page');
});