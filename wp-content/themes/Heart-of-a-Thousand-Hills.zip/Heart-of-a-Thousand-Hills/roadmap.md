# A list of files that need to be written

* functions.php
* index.php
* header.php
* footer.php
* page.php
* single.php
* content.php (with all content types)
* author archives
* date archives
* category and tag archives
* 404.php
* full width template
* contact template
* widgets
* css