<?php 
/**
 * init.php
 *
 * Load the widget files.
 */
 
require_once( FRAMEWORK . '/widgets/widget-business-hours.php' );
?>